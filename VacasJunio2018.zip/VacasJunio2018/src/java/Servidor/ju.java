package Servidor;

import com.sun.faces.taglib.html_basic.DataTableTag;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;
/**
 *
 * @author Diego
 */
@WebService(serviceName = "ju")
public class ju {

    public PreparedStatement prep;
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
//    @WebMethod(operationName = "empresa")
    public String empresa(String txt, String txt1) throws SQLException {
        Connection c = null;
        Statement stmt = null;
        try{
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/sistemaerp","postgres", "");
            System.out.println("Opened database successfully");
            stmt = c.createStatement();
            String sql = "INSERT INTO Empresa (nombEmp,Propietario) VALUES ( '"+txt+"', '"+txt1+"');";
            stmt.execute(sql);
            
        }catch(Exception e){
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }
        return txt;
    }
    
    public String empleado(String nombre, String puesto, String user, String contra, int empid) throws SQLException {
        Connection c = null;
        Statement stmt = null;
        try{
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/sistemaerp","postgres", "");
            System.out.println("Opened database successfully");
            stmt = c.createStatement();
            String sql = "INSERT INTO Empleado (Nombre, Puesto, Usuario, Contraseña, idEmpre) VALUES ( '"+nombre+"', '"+puesto+"', '"+user+"', '"+contra+"', "+empid+");";
            stmt.execute(sql);
            
        }catch(Exception e){
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }
        return "g";
    }
    
    public ArrayList<String[]> LogIn(String user, String contra){
        ArrayList<String[]> data2 = new ArrayList<String[]>();
        Connection c = null;
        Statement stmt = null;
        try{
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/sistemaerp","postgres", "");
            System.out.println("Opened database successfully");
            stmt = c.createStatement();
            String sql = "SELECT * FROM Empleado WHERE Usuario = '"+user+"', AND Contraseña = '"+contra+"';";
            ResultSet rs1 = prep.executeQuery(sql);
            stmt.execute(sql);
            while(rs1.next()) {
               String[] dataSQL = new String[5];
                dataSQL[0]= rs1.getString("idEmpleado");
                dataSQL[1]= rs1.getString("Nombre");
                dataSQL[2] = rs1.getString("Puesto");
                dataSQL[3]= rs1.getString("Usuario");
                dataSQL[4] = rs1.getString("Contraseña");
                dataSQL[5] = rs1.getString("idEmpre");
                data2.add(dataSQL);
                System.out.println(rs1.getString("idEmpleado"));
                System.out.println(rs1.getString("Nombre"));
                System.out.println(rs1.getString("Puesto"));
                System.out.println(rs1.getString("Usuario"));
                System.out.println(rs1.getString("Contraseña"));
                System.out.println(rs1.getString("idEmpre"));
            }

        }catch(Exception e){
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            System.exit(0);
        }
        return data2;
    }
    
}
